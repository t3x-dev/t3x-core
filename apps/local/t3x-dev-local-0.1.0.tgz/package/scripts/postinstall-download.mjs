#!/usr/bin/env node

import { spawnSync } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {
  assertRuntimeLayout,
  ensureDir,
  fileExists,
  getDefaultInstalledRuntimeDir,
  getLocalPackageDir,
  getPlatformKey,
  getRuntimeManifestPath,
  readJson,
  resolveMirrorArtifactLocation,
} from './runtime-helpers.mjs';

if (process.env.T3X_LOCAL_SKIP_DOWNLOAD === '1' || process.env.T3X_LOCAL_SKIP_DOWNLOAD === 'true') {
  console.log(
    '[t3x-local:postinstall] Skipping runtime download because T3X_LOCAL_SKIP_DOWNLOAD is set.'
  );
  process.exit(0);
}

const packageDir = getLocalPackageDir();
const manifestPath = getRuntimeManifestPath(packageDir);

if (!(await fileExists(manifestPath))) {
  console.log('[t3x-local:postinstall] No runtime manifest found. Skipping runtime download.');
  process.exit(0);
}

const manifest = await readJson(manifestPath);
const platformKey = getPlatformKey();
const artifact = manifest.platforms?.[platformKey];

if (!artifact) {
  throw new Error(`[t3x-local:postinstall] No runtime artifact configured for ${platformKey}`);
}

const runtimeDir = path.resolve(
  process.env.T3X_LOCAL_RUNTIME_DIR ?? getDefaultInstalledRuntimeDir(packageDir)
);
const downloadSource = process.env.T3X_LOCAL_RUNTIME_MIRROR
  ? resolveMirrorArtifactLocation(process.env.T3X_LOCAL_RUNTIME_MIRROR, artifact.fileName)
  : artifact.url;

if (!downloadSource) {
  throw new Error(
    '[t3x-local:postinstall] Runtime manifest did not contain a URL and no T3X_LOCAL_RUNTIME_MIRROR was provided.'
  );
}

const tempDir = await fs.mkdtemp(path.join(os.tmpdir(), 't3x-local-postinstall-'));
const archivePath = path.join(tempDir, artifact.fileName);

try {
  await downloadArtifact(downloadSource, archivePath);
  await verifyArchiveSha(archivePath, artifact.sha256);

  await fs.rm(runtimeDir, { recursive: true, force: true });
  await ensureDir(runtimeDir);

  const extractResult = spawnSync('tar', ['-xzf', archivePath, '-C', runtimeDir], {
    stdio: 'inherit',
  });

  if (extractResult.status !== 0) {
    throw new Error(
      `[t3x-local:postinstall] tar extraction failed with exit code ${String(extractResult.status)}`
    );
  }

  await assertRuntimeLayout(runtimeDir);
  await ensurePackageNodeModulesLink(runtimeDir, packageDir);
  await fs.writeFile(
    path.join(runtimeDir, '.runtime-download.json'),
    `${JSON.stringify(
      {
        packageVersion: manifest.packageVersion,
        platform: platformKey,
        source: downloadSource,
        sha256: artifact.sha256,
        installedAt: new Date().toISOString(),
      },
      null,
      2
    )}\n`,
    'utf8'
  );

  console.log(`[t3x-local:postinstall] Runtime ready at ${runtimeDir}`);
} finally {
  await fs.rm(tempDir, { recursive: true, force: true });
}

async function downloadArtifact(source, destinationPath) {
  if (source.startsWith('file://')) {
    await fs.copyFile(new URL(source), destinationPath);
    return;
  }

  if (source.startsWith('http://') || source.startsWith('https://')) {
    const response = await fetch(source);

    if (!response.ok) {
      throw new Error(
        `[t3x-local:postinstall] Failed to download runtime: HTTP ${response.status}`
      );
    }

    const arrayBuffer = await response.arrayBuffer();
    await fs.writeFile(destinationPath, new Uint8Array(arrayBuffer));
    return;
  }

  await fs.copyFile(source, destinationPath);
}

async function verifyArchiveSha(archivePath, expectedSha) {
  const file = await fs.readFile(archivePath);
  const actualSha = crypto.createHash('sha256').update(file).digest('hex');

  if (actualSha !== expectedSha) {
    throw new Error(
      `[t3x-local:postinstall] SHA256 mismatch for runtime archive. Expected ${expectedSha}, got ${actualSha}`
    );
  }
}

async function ensurePackageNodeModulesLink(runtimeDir, packageDir) {
  const runtimeNodeModulesPath = path.join(runtimeDir, 'node_modules');
  const packageNodeModulesPath = path.join(packageDir, 'node_modules');

  if (!(await fileExists(packageNodeModulesPath))) {
    return;
  }

  await fs.rm(runtimeNodeModulesPath, { recursive: true, force: true });
  await fs.symlink(packageNodeModulesPath, runtimeNodeModulesPath, 'junction');
}
