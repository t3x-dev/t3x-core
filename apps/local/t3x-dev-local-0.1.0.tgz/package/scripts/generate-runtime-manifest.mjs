#!/usr/bin/env node

import path from 'node:path';
import {
  getLocalPackageDir,
  getPlatformKey,
  getRuntimeArtifactFileName,
  getRuntimeArtifactsDir,
  getRuntimeManifestPath,
  readJson,
  sha256File,
  statSize,
  writeJson,
} from './runtime-helpers.mjs';

const packageDir = getLocalPackageDir();
const repoRoot = path.resolve(packageDir, '../..');
const localPackageJson = await readJson(path.join(packageDir, 'package.json'));
const apiPackageJson = await readJson(path.join(repoRoot, 'packages', 'api', 'package.json'));
const storagePackageJson = await readJson(
  path.join(repoRoot, 'packages', 'storage', 'package.json')
);
const webPackageJson = await readJson(path.join(repoRoot, 'apps', 'web', 'package.json'));
const cliPackageJson = await readJson(path.join(repoRoot, 'apps', 'cli', 'package.json'));
const mcpPackageJson = await readJson(path.join(repoRoot, 'apps', 'mcp', 'package.json'));
const platformKey = process.env.T3X_LOCAL_RUNTIME_PLATFORM ?? getPlatformKey();
const artifactsDir = path.resolve(
  process.env.T3X_LOCAL_RUNTIME_OUTPUT_DIR ?? getRuntimeArtifactsDir(packageDir)
);
const artifactFileName = getRuntimeArtifactFileName(localPackageJson.version, platformKey);
const artifactPath = path.join(artifactsDir, artifactFileName);
const manifestPath = getRuntimeManifestPath(packageDir);
const releaseBaseUrl =
  process.env.T3X_LOCAL_RUNTIME_BASE_URL ??
  `https://github.com/t3x-dev/t3x-core/releases/download/t3x-local-v${localPackageJson.version}`;

const sha256 = await sha256File(artifactPath);
const size = await statSize(artifactPath);

const manifest = {
  manifestVersion: 1,
  packageVersion: localPackageJson.version,
  generatedAt: new Date().toISOString(),
  dependencies: {
    '@t3x-dev/api': apiPackageJson.version,
    '@t3x-dev/storage': storagePackageJson.version,
    '@t3x-dev/cli': cliPackageJson.version,
    '@t3x-dev/mcp': mcpPackageJson.version,
    web: webPackageJson.version,
  },
  platforms: {
    [platformKey]: {
      fileName: artifactFileName,
      url: `${releaseBaseUrl.replace(/\/$/, '')}/${artifactFileName}`,
      sha256,
      size,
    },
  },
};

await writeJson(manifestPath, manifest);
console.log(`[generate-runtime-manifest] Wrote ${manifestPath}`);
